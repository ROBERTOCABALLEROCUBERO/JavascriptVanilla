var miguel = document.getElementById('boton1');

miguel.addEventListener('click', function(){
alert("Cargado");

})