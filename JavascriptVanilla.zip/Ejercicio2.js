let num = [4,16,25,36];

let nuevoarray = num.map(edad => raiz = Math.sqrt(edad)).filter(edad => edad >= 4);

alert(nuevoarray);