let num = [40,30,20,70,80];

let nummay= num.find(edad => edad > 50);

alert (nummay);