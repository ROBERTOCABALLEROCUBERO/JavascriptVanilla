let mayus = ["hola", "mundo", "dos"];

let arrmay = mayus.map(mayuscula => mayuscula.toUpperCase());

alert(arrmay);