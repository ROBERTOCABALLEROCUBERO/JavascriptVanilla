let num = [40,30,20,70,80];


let arrayfiltrado = num.filter(edad => edad >=50);

alert(arrayfiltrado);


