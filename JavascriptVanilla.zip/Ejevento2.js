function cambio(){

        document.getElementById("estela1").style.zIndex = 1;
        document.getElementById("estela2").style.zIndex = 0;

}

function cambio2(){document.getElementById("estela2").style.zIndex = 1;
document.getElementById("estela1").style.zIndex = 0;}